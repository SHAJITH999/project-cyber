#include<stdio.h>
int fib(int f,int a,int b){
int i,c=0;
for(i=0;i<f-2;i++)
{
 c=a+b;
 a=b;
 b=c;
 }

return c;
}
int main(){
int f,c;
int a=0;
int b=1;
printf("Enter the no : ");
scanf("%d ",&f);
c=fib(f,a,b);
printf("The sum is %d ",c);
return 0;
}

