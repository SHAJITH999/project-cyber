#include<stdio.h>
int sq(int a){
int sq=a*a;
 return sq;
  }
   int main(){
   int a ;
   scanf("%d",&a);
   printf("%d",sq(a));
   return 0;
   }
