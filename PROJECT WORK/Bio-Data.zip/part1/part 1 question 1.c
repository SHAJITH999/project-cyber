#include<stdio.h>
int main(){
printf("4>3>2 , 2+3>4+5 , 6>3+2<5 ");
int a,b,c;
a = 4>3>2;
b = 2+3>4+5;
c = 6>3+2<5;
printf("\nAnswer : %d,%d,%d ",a,b,c);
return 0;
}
