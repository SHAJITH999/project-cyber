#include <stdio.h>
int main(){
int a = 4>3 && 3>2;
printf("4>3 && 3>2 = %d\n",a);
return 0;
}
