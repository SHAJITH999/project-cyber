#include<stdio.h>
int main()
{
int a,b;
printf("Enter a number : ");
scanf("%d",&a);
printf("a<<= 4 : %d",a<<=4);
printf("\na>>= 3 : %d",a>>=3);
return 0;
}
