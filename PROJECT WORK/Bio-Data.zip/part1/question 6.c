#include <stdio.h>
int main(){
int a,b,c,d,e;
a = 4 > 5;
b = 4 < 5;
c = 4 >= 5;
d = 5 == 5;
e = 4 == 5;
printf("4>5,4<5,4>=5,5==5,4==5 :\n %d,%d,%d,%d,%d",a,b,c,d,e);
return 0;
}
