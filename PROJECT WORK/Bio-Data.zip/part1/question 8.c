#include<stdio.h>
int main()
{
int a,b;
printf("Enter a number : ");
scanf("%d",&a);
b = !!!!a;
printf("!!!!a = %d",b);
return 0;
}

